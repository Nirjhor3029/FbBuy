<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoughTest extends Model
{
    //
}
