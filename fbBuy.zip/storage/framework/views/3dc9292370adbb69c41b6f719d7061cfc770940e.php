<?php
/**
 * Created by PhpStorm.
 * User: Nirjhor
 * Date: 12/24/2018
 * Time: 6:50 PM
 */
use Illuminate\Support\Facades\Auth;


?>

<?php if(Auth::guard('web')->check()): ?>
    <p class="text-success">
        You are Logged in as a <strong>User</strong>
    </p>
<?php else: ?>
    <p class="text-danger">
        You are Logged Out as a <strong>User</strong>
    </p>

<?php endif; ?>




<?php if(Auth::guard('admin')->check()): ?>
    <p class="text-success">
        You are Logged in as a <strong>Admin</strong>
    </p>
<?php else: ?>
    <p class="text-danger">
        You are Logged Out as a <strong>Admin</strong>
    </p>

<?php endif; ?>


<?php if(Auth::guard('vendor')->check()): ?>
    <p class="text-success">
        You are Logged in as a <strong>Vendor</strong>
    </p>
<?php else: ?>
    <p class="text-danger">
        You are Logged Out as a <strong>Vendor</strong>
    </p>

<?php endif; ?>