<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 12/23/2018
 * Time: 3:52 PM
 */
?>




<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Vendor Dashboard</div>

                    <div class="panel-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php $__env->startComponent('components.who'); ?>
                        <?php echo $__env->renderComponent(); ?>

                        <button class="btn btn-primary">Login With Facebook</button>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.vendor_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>